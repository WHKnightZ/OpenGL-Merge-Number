#include "../Library/loadpng.h"
#include <GL/glut.h>

#define WIDTH 424
#define HEIGHT 424
#define POS_X 420
#define POS_Y 160

#define MAX 5
#define SIZE_CELL 60
#define SIZE_SPACE 6
#define SIZE_CELL_FULL 66
#define START_X 50
#define START_Y 50
#define FULL_X 374 // = START_X + MAX * SIZE_CELL_FULL - SIZE_SPACE
#define FULL_Y 374

#define INTERVAL 30
#define MAX_ANIMATION 12

#define SIZE_HON_RIPPLE 14
#define SIZE_VER_RIPPLE 60 // = SIZE_CELL
#define SIZE_HON_TAIL 30
#define SIZE_VER_TAIL 12 // = SIZE_CELL / 5
#define SIZE_HON_SQUARE 76 // SIZE_CELL_FULL + SIZE_CELL / 6
#define SIZE_VER_SQUARE 60 // = SIZE_CELL
#define DIS_TAIL 24 // = SIZE_CELL * 2 / 5
#define DONE_RIPPLE 12
#define DONE_TAIL 22
#define DONE_SQUARE 11
#define BFS_MAX_DEGREE 24
#define BFS_MAX_PER_DEGREE 24
#define OFFSET_JOINT_SQUARE 16 // = SIZE_CELL / 6 + SIZE_SPACE
#define SIZE_JOINT_SQUARE 26 // = SIZE_CELL * 2 / 6 + SIZE_SPACE

typedef struct Struct_Animation {
    int Color;
    int Drt, Pos_Offset[3];
    char Done_Tail[3];
    float Left_Ripple, Right_Ripple, Bottom_Ripple, Top_Ripple;
    float Left_Square, Right_Square, Bottom_Square, Top_Square;
    float Left_Tail[3], Right_Tail[3], Bottom_Tail[3], Top_Tail[3];
} Struct_Animation;

typedef struct Image {
    GLubyte* img;
    GLuint w, h;
} Image;

typedef struct Struct_Def_Drt {
    char x, y;
} Struct_Def_Drt;

typedef struct Struct_BFS {
    char x, y;
    int Drt;
} Struct_BFS;

typedef struct Struct_BFS_Mark {
    char x, y;
} Struct_BFS_Mark;

typedef struct Struct_Joint_Square {
    float Left, Right, Bottom, Top;
} Struct_Joint_Square;

void (*Init_Pos_Ani[4])(Struct_Animation*, char*, char*);
void (*Action_Effect_Ani[4])(Struct_Animation*);
int (*Check_Equal[4])(char, char);
void (*Create_Joint_Square[4])(char*, char*);

Struct_Animation* Ptr_Ani;
Struct_Animation Animation[MAX_ANIMATION];
Struct_Def_Drt Def_Drt[4] = { { 0, -1 }, { 1, 0 }, { 0, 1 }, { -1, 0 } };
Struct_BFS* Ptr_BFS;
Struct_BFS BFS_List[BFS_MAX_DEGREE][BFS_MAX_PER_DEGREE];
Struct_BFS_Mark BFS_List_Mark[25];
Struct_Joint_Square Joint_Square[25];
Image Img_Block_Full, Img_Block_Ripple[4], Img_Block_Tail[4];

int Count_Joint_Square;
int BFS_Count_List_Mark;
int BFS_Count_List[BFS_MAX_DEGREE];
char BFS_Mark[MAX][MAX];
int BFS_Count, BFS_Degree, xx, yy;
int Pos_Effect = DONE_TAIL, Count_Animation;
char Current_Value;
float Offset_Ripple[DONE_RIPPLE] = { 9.0f };
float Offset_Tail[3][DONE_TAIL] = { { 8.0f }, { 6.0f }, { 7.0f } };
const int Offset_Done[3] = { 13, 22, 17 };
float Pos_Left[MAX];
float Pos_Right[MAX];
float Pos_Bottom[MAX];
float Pos_Top[MAX];

char Map[MAX][MAX] = {
    { 1, 0, 1, 1, 1 },
    { 1, 0, 1, 0, 1 },
    { 1, 0, 1, 0, 1 },
    { 1, 0, 1, 0, 1 },
    { 1, 1, 1, 0, 1 },
};

int Loop_Next[] = { 1, 2, 0 };
int Reverse_Drt[] = { 2, 3, 0, 1 };
int Tmp_Int, Tmp_Int_2;
int i, j, k, ii, jj, kk;

float Color_Block[][3] = {
    { 0.902f, 0.675f, 0.706f },
    { 0.655f, 0.847f, 0.925f },
    { 0.757f, 0.878f, 0.675f },
    { 0.918f, 0.906f, 0.580f },
    { 0.890f, 0.725f, 0.914f },
    { 0.953f, 0.443f, 0.392f },
};

float Color_Number[][3] = {
    { 0.620f, 0.400f, 0.431f },
    { 0.322f, 0.565f, 0.655f }
};

void Load_Texture(Image* img, const char* path)
{
    loadPng(&img->img, &img->w, &img->h, path);
}

void Map_Texture(Image* img)
{
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img->w, img->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, img->img);
}

int Check_Done_Ripple()
{
    return Pos_Effect >= DONE_RIPPLE;
}

int Check_Done_Square()
{
    return Pos_Effect >= DONE_SQUARE;
}

int Check_Done_Effect()
{
    return Pos_Effect >= DONE_TAIL;
}

int Check_Equal_Up(char x, char y)
{
    y--;
    if (y > -1) {
        if (!BFS_Mark[y][x]) {
            BFS_Mark[y][x] = 1;
            BFS_List_Mark[BFS_Count_List_Mark].x = x;
            BFS_List_Mark[BFS_Count_List_Mark].y = y;
            BFS_Count_List_Mark++;
            if (Map[y][x] == Current_Value)
                return 1;
        }
    }
    return 0;
}
int Check_Equal_Down(char x, char y)
{
    y++;
    if (y < MAX) {
        if (!BFS_Mark[y][x]) {
            BFS_Mark[y][x] = 1;
            BFS_List_Mark[BFS_Count_List_Mark].x = x;
            BFS_List_Mark[BFS_Count_List_Mark].y = y;
            BFS_Count_List_Mark++;
            if (Map[y][x] == Current_Value)
                return 1;
        }
    }
    return 0;
}
int Check_Equal_Left(char x, char y)
{
    x--;
    if (x > -1) {
        if (!BFS_Mark[y][x]) {
            BFS_Mark[y][x] = 1;
            BFS_List_Mark[BFS_Count_List_Mark].x = x;
            BFS_List_Mark[BFS_Count_List_Mark].y = y;
            BFS_Count_List_Mark++;
            if (Map[y][x] == Current_Value)
                return 1;
        }
    }
    return 0;
}
int Check_Equal_Right(char x, char y)
{
    x++;
    if (x < MAX) {
        if (!BFS_Mark[y][x]) {
            BFS_Mark[y][x] = 1;
            BFS_List_Mark[BFS_Count_List_Mark].x = x;
            BFS_List_Mark[BFS_Count_List_Mark].y = y;
            BFS_Count_List_Mark++;
            if (Map[y][x] == Current_Value)
                return 1;
        }
    }
    return 0;
}

void Init_Pos_LRBT()
{
    for (i = 0; i < MAX; i++) {
        Pos_Left[i] = START_X + i * SIZE_CELL_FULL;
        Pos_Right[i] = Pos_Left[i] + SIZE_CELL;
        Pos_Bottom[i] = START_Y + i * SIZE_CELL_FULL;
        Pos_Top[i] = Pos_Bottom[i] + SIZE_CELL;
    }
}

void Init_Pos_Offset()
{
    for (i = 0; i < MAX_ANIMATION; i++) {
        Animation[i].Pos_Offset[0] = rand() % 3;
        do {
            Animation[i].Pos_Offset[1] = rand() % 3;
        } while (Animation[i].Pos_Offset[0] == Animation[i].Pos_Offset[1]);
        Animation[i].Pos_Offset[2] = 3 - (Animation[i].Pos_Offset[0] + Animation[i].Pos_Offset[1]);
    }
}

void Init_Pos_Ani_Up(Struct_Animation* ptr, char* x, char* y)
{
    ptr->Left_Ripple = ptr->Left_Square = ptr->Left_Tail[0] = Pos_Left[*x];
    ptr->Right_Ripple = ptr->Right_Square = ptr->Right_Tail[2] = Pos_Right[*x];
    ptr->Top_Ripple = ptr->Top_Tail[0] = ptr->Top_Tail[1] = ptr->Top_Tail[2] = Pos_Top[*y];
    ptr->Bottom_Ripple = ptr->Top_Ripple - SIZE_HON_RIPPLE;
    ptr->Top_Square = ptr->Bottom_Ripple;
    ptr->Bottom_Square = ptr->Top_Ripple - SIZE_HON_SQUARE;
    ptr->Bottom_Tail[0] = ptr->Bottom_Tail[1] = ptr->Bottom_Tail[2] = ptr->Top_Ripple - SIZE_HON_TAIL;
    ptr->Left_Tail[1] = ptr->Left_Tail[0] + DIS_TAIL;
    ptr->Left_Tail[2] = ptr->Left_Tail[1] + DIS_TAIL;
    ptr->Right_Tail[0] = ptr->Left_Tail[0] + SIZE_VER_TAIL;
    ptr->Right_Tail[1] = ptr->Left_Tail[1] + SIZE_VER_TAIL;
}
void Init_Pos_Ani_Down(Struct_Animation* ptr, char* x, char* y)
{
    ptr->Left_Ripple = ptr->Left_Square = ptr->Left_Tail[0] = Pos_Left[*x];
    ptr->Right_Ripple = ptr->Right_Square = ptr->Right_Tail[2] = Pos_Right[*x];
    ptr->Bottom_Ripple = ptr->Bottom_Tail[0] = ptr->Bottom_Tail[1] = ptr->Bottom_Tail[2] = Pos_Bottom[*y];
    ptr->Top_Ripple = ptr->Bottom_Ripple + SIZE_HON_RIPPLE;
    ptr->Bottom_Square = ptr->Top_Ripple;
    ptr->Top_Square = ptr->Bottom_Ripple + SIZE_HON_SQUARE;
    ptr->Top_Tail[0] = ptr->Top_Tail[1] = ptr->Top_Tail[2] = ptr->Top_Ripple + SIZE_HON_TAIL;
    ptr->Left_Tail[1] = ptr->Left_Tail[0] + DIS_TAIL;
    ptr->Left_Tail[2] = ptr->Left_Tail[1] + DIS_TAIL;
    ptr->Right_Tail[0] = ptr->Left_Tail[0] + SIZE_VER_TAIL;
    ptr->Right_Tail[1] = ptr->Left_Tail[1] + SIZE_VER_TAIL;
}
void Init_Pos_Ani_Left(Struct_Animation* ptr, char* x, char* y)
{
    ptr->Bottom_Ripple = ptr->Bottom_Square = ptr->Bottom_Tail[0] = Pos_Bottom[*y];
    ptr->Top_Ripple = ptr->Top_Square = ptr->Top_Tail[2] = Pos_Top[*y];
    ptr->Right_Ripple = ptr->Right_Tail[0] = ptr->Right_Tail[1] = ptr->Right_Tail[2] = Pos_Right[*x];
    ptr->Left_Ripple = ptr->Right_Ripple - SIZE_HON_RIPPLE;
    ptr->Right_Square = ptr->Left_Ripple;
    ptr->Left_Square = ptr->Right_Ripple - SIZE_HON_SQUARE;
    ptr->Left_Tail[0] = ptr->Left_Tail[1] = ptr->Left_Tail[2] = ptr->Right_Ripple - SIZE_HON_TAIL;
    ptr->Bottom_Tail[1] = ptr->Bottom_Tail[0] + DIS_TAIL;
    ptr->Bottom_Tail[2] = ptr->Bottom_Tail[1] + DIS_TAIL;
    ptr->Top_Tail[0] = ptr->Bottom_Tail[0] + SIZE_VER_TAIL;
    ptr->Top_Tail[1] = ptr->Bottom_Tail[1] + SIZE_VER_TAIL;
}
void Init_Pos_Ani_Right(Struct_Animation* ptr, char* x, char* y)
{
    ptr->Bottom_Ripple = ptr->Bottom_Square = ptr->Bottom_Tail[0] = Pos_Bottom[*y];
    ptr->Top_Ripple = ptr->Top_Square = ptr->Top_Tail[2] = Pos_Top[*y];
    ptr->Left_Ripple = ptr->Left_Tail[0] = ptr->Left_Tail[1] = ptr->Left_Tail[2] = Pos_Left[*x];
    ptr->Right_Ripple = ptr->Left_Ripple + SIZE_HON_RIPPLE;
    ptr->Left_Square = ptr->Right_Ripple;
    ptr->Right_Square = ptr->Left_Ripple + SIZE_HON_SQUARE;
    ptr->Right_Tail[0] = ptr->Right_Tail[1] = ptr->Right_Tail[2] = ptr->Left_Ripple + SIZE_HON_TAIL;
    ptr->Bottom_Tail[1] = ptr->Bottom_Tail[0] + DIS_TAIL;
    ptr->Bottom_Tail[2] = ptr->Bottom_Tail[1] + DIS_TAIL;
    ptr->Top_Tail[0] = ptr->Bottom_Tail[0] + SIZE_VER_TAIL;
    ptr->Top_Tail[1] = ptr->Bottom_Tail[1] + SIZE_VER_TAIL;
}

void Action_Effect_Ani_Up(Struct_Animation* ptr)
{
    if (!Check_Done_Ripple()) {
        ptr->Bottom_Ripple -= Offset_Ripple[Pos_Effect];
        ptr->Top_Ripple -= Offset_Ripple[Pos_Effect];
        ptr->Top_Square = ptr->Bottom_Ripple;
    }
    for (ii = 0; ii < 3; ii++) {
        if (!ptr->Done_Tail[ii]) {
            ptr->Bottom_Tail[ii] -= Offset_Tail[ptr->Pos_Offset[ii]][Pos_Effect];
            ptr->Top_Tail[ii] = ptr->Bottom_Tail[ii] + SIZE_HON_TAIL;
            if (Pos_Effect == Offset_Done[ptr->Pos_Offset[ii]])
                ptr->Done_Tail[ii] = 1;
        }
    }
}
void Action_Effect_Ani_Down(Struct_Animation* ptr)
{
    if (!Check_Done_Ripple()) {
        ptr->Bottom_Ripple += Offset_Ripple[Pos_Effect];
        ptr->Top_Ripple += Offset_Ripple[Pos_Effect];
        ptr->Bottom_Square = ptr->Top_Ripple;
    }
    for (ii = 0; ii < 3; ii++) {
        if (!ptr->Done_Tail[ii]) {
            ptr->Bottom_Tail[ii] += Offset_Tail[ptr->Pos_Offset[ii]][Pos_Effect];
            ptr->Top_Tail[ii] = ptr->Bottom_Tail[ii] + SIZE_HON_TAIL;
            if (Pos_Effect == Offset_Done[ptr->Pos_Offset[ii]])
                ptr->Done_Tail[ii] = 1;
        }
    }
}
void Action_Effect_Ani_Left(Struct_Animation* ptr)
{
    if (!Check_Done_Ripple()) {
        ptr->Left_Ripple -= Offset_Ripple[Pos_Effect];
        ptr->Right_Ripple -= Offset_Ripple[Pos_Effect];
        ptr->Right_Square = ptr->Left_Ripple;
    }
    for (ii = 0; ii < 3; ii++) {
        if (!ptr->Done_Tail[ii]) {
            ptr->Left_Tail[ii] -= Offset_Tail[ptr->Pos_Offset[ii]][Pos_Effect];
            ptr->Right_Tail[ii] = ptr->Left_Tail[ii] + SIZE_HON_TAIL;
            if (Pos_Effect == Offset_Done[ptr->Pos_Offset[ii]])
                ptr->Done_Tail[ii] = 1;
        }
    }
}
void Action_Effect_Ani_Right(Struct_Animation* ptr)
{
    if (!Check_Done_Ripple()) {
        ptr->Left_Ripple += Offset_Ripple[Pos_Effect];
        ptr->Right_Ripple += Offset_Ripple[Pos_Effect];
        ptr->Left_Square = ptr->Right_Ripple;
    }
    for (ii = 0; ii < 3; ii++) {
        if (!ptr->Done_Tail[ii]) {
            ptr->Left_Tail[ii] += Offset_Tail[ptr->Pos_Offset[ii]][Pos_Effect];
            ptr->Right_Tail[ii] = ptr->Left_Tail[ii] + SIZE_HON_TAIL;
            if (Pos_Effect == Offset_Done[ptr->Pos_Offset[ii]])
                ptr->Done_Tail[ii] = 1;
        }
    }
}

void Draw_Effect_Ani(Struct_Animation* ptr)
{
    if (!Check_Done_Ripple()) {
        Map_Texture(&Img_Block_Ripple[ptr->Drt]);
        glBegin(GL_POLYGON);
        glTexCoord2f(0.0f, 0.0f);
        glVertex2f(ptr->Left_Ripple, ptr->Bottom_Ripple);
        glTexCoord2f(1.0f, 0.0f);
        glVertex2f(ptr->Right_Ripple, ptr->Bottom_Ripple);
        glTexCoord2f(1.0f, 1.0f);
        glVertex2f(ptr->Right_Ripple, ptr->Top_Ripple);
        glTexCoord2f(0.0f, 1.0f);
        glVertex2f(ptr->Left_Ripple, ptr->Top_Ripple);
        glEnd();
    }
    if (!Check_Done_Square()) {
        glDisable(GL_TEXTURE_2D);
        glBegin(GL_POLYGON);
        glTexCoord2f(0.0f, 0.0f);
        glVertex2f(ptr->Left_Square, ptr->Bottom_Square);
        glTexCoord2f(1.0f, 0.0f);
        glVertex2f(ptr->Right_Square, ptr->Bottom_Square);
        glTexCoord2f(1.0f, 1.0f);
        glVertex2f(ptr->Right_Square, ptr->Top_Square);
        glTexCoord2f(0.0f, 1.0f);
        glVertex2f(ptr->Left_Square, ptr->Top_Square);
        glEnd();
        glEnable(GL_TEXTURE_2D);
    }
    Map_Texture(&Img_Block_Tail[ptr->Drt]);
    for (jj = 0; jj < 3; jj++) {
        if (!ptr->Done_Tail[jj]) {
            glBegin(GL_POLYGON);
            glTexCoord2f(0.0f, 0.0f);
            glVertex2f(ptr->Left_Tail[jj], ptr->Bottom_Tail[jj]);
            glTexCoord2f(1.0f, 0.0f);
            glVertex2f(ptr->Right_Tail[jj], ptr->Bottom_Tail[jj]);
            glTexCoord2f(1.0f, 1.0f);
            glVertex2f(ptr->Right_Tail[jj], ptr->Top_Tail[jj]);
            glTexCoord2f(0.0f, 1.0f);
            glVertex2f(ptr->Left_Tail[jj], ptr->Top_Tail[jj]);
            glEnd();
        }
    }
}

void Create_Animation(char x, char y, int Drt)
{
    Map[y][x] = -1;
    Ptr_Ani = &Animation[Count_Animation];
    Ptr_Ani->Drt = Drt;
    Ptr_Ani->Color = Map[y + Def_Drt[Drt].y][x + Def_Drt[Drt].x];
    Ptr_Ani->Done_Tail[0] = Ptr_Ani->Done_Tail[1] = Ptr_Ani->Done_Tail[2] = 0;
    Tmp_Int = rand() % 3;
    Tmp_Int_2 = Ptr_Ani->Pos_Offset[Tmp_Int];
    Ptr_Ani->Pos_Offset[Tmp_Int] = Ptr_Ani->Pos_Offset[Loop_Next[Tmp_Int]];
    Ptr_Ani->Pos_Offset[Loop_Next[Tmp_Int]] = Tmp_Int_2;
    Init_Pos_Ani[Drt](Ptr_Ani, &x, &y);
    Count_Animation++;
}

void Create_Joint_Square_Up(char* x, char* y)
{
    Joint_Square[Count_Joint_Square].Left = Pos_Left[*x];
    Joint_Square[Count_Joint_Square].Right = Pos_Right[*x];
    Joint_Square[Count_Joint_Square].Bottom = Pos_Bottom[*y] - OFFSET_JOINT_SQUARE;
    Joint_Square[Count_Joint_Square].Top = Joint_Square[Count_Joint_Square].Bottom + SIZE_JOINT_SQUARE;
    Count_Joint_Square++;
}
void Create_Joint_Square_Down(char* x, char* y)
{
    Joint_Square[Count_Joint_Square].Left = Pos_Left[*x];
    Joint_Square[Count_Joint_Square].Right = Pos_Right[*x];
    Joint_Square[Count_Joint_Square].Top = Pos_Top[*y] + OFFSET_JOINT_SQUARE;
    Joint_Square[Count_Joint_Square].Bottom = Joint_Square[Count_Joint_Square].Top - SIZE_JOINT_SQUARE;
    Count_Joint_Square++;
}
void Create_Joint_Square_Left(char* x, char* y)
{
    Joint_Square[Count_Joint_Square].Bottom = Pos_Bottom[*y];
    Joint_Square[Count_Joint_Square].Top = Pos_Top[*y];
    Joint_Square[Count_Joint_Square].Left = Pos_Left[*x] - OFFSET_JOINT_SQUARE;
    Joint_Square[Count_Joint_Square].Right = Joint_Square[Count_Joint_Square].Left + SIZE_JOINT_SQUARE;
    Count_Joint_Square++;
}
void Create_Joint_Square_Right(char* x, char* y)
{
    Joint_Square[Count_Joint_Square].Bottom = Pos_Bottom[*y];
    Joint_Square[Count_Joint_Square].Top = Pos_Top[*y];
    Joint_Square[Count_Joint_Square].Right = Pos_Right[*x] + OFFSET_JOINT_SQUARE;
    Joint_Square[Count_Joint_Square].Left = Joint_Square[Count_Joint_Square].Right - SIZE_JOINT_SQUARE;
    Count_Joint_Square++;
}

void BFS_Find(char x, char y)
{
    Current_Value = Map[y][x];
    BFS_Degree = 0;
    BFS_Count = 0;
    BFS_Count_List[BFS_Degree] = 0;
    BFS_List_Mark[0].x = x;
    BFS_List_Mark[0].y = y;
    BFS_Count_List_Mark = 1;
    BFS_Mark[y][x] = 1;
    for (kk = 0; kk < 4; kk++) {
        if (Check_Equal[kk](x, y)) {
            Ptr_BFS = &BFS_List[BFS_Degree][BFS_Count_List[BFS_Degree]];
            Ptr_BFS->x = x + Def_Drt[kk].x;
            Ptr_BFS->y = y + Def_Drt[kk].y;
            Ptr_BFS->Drt = Reverse_Drt[kk];
            BFS_Count_List[BFS_Degree]++;
            BFS_Count++;
        }
    }
    while (BFS_Count_List[BFS_Degree]) {
        BFS_Count_List[BFS_Degree + 1] = 0;
        for (k = 0; k < BFS_Count_List[BFS_Degree]; k++) {
            xx = BFS_List[BFS_Degree][k].x;
            yy = BFS_List[BFS_Degree][k].y;
            for (kk = 0; kk < 4; kk++) {
                if (Check_Equal[kk](xx, yy)) {
                    Ptr_BFS = &BFS_List[BFS_Degree + 1][BFS_Count_List[BFS_Degree + 1]];
                    Ptr_BFS->x = xx + Def_Drt[kk].x;
                    Ptr_BFS->y = yy + Def_Drt[kk].y;
                    Ptr_BFS->Drt = Reverse_Drt[kk];
                    BFS_Count_List[BFS_Degree + 1]++;
                    BFS_Count++;
                }
            }
        }
        BFS_Degree++;
    }
    for (k = 0; k < BFS_Count_List_Mark; k++)
        BFS_Mark[BFS_List_Mark[k].y][BFS_List_Mark[k].x] = 0;
    Count_Joint_Square = 0;
    for (k = 0; k < BFS_Degree - 1; k++)
        for (kk = 0; kk < BFS_Count_List[k]; kk++)
            Create_Joint_Square[BFS_List[k][kk].Drt](&BFS_List[k][kk].x, &BFS_List[k][kk].y);
}

void Init_Game()
{
    Load_Texture(&Img_Block_Full, "Images/Block_Full.png");
    Load_Texture(&Img_Block_Ripple[0], "Images/Block_Ripple_Up.png");
    Load_Texture(&Img_Block_Tail[0], "Images/Block_Tail_Up.png");
    Load_Texture(&Img_Block_Ripple[1], "Images/Block_Ripple_Right.png");
    Load_Texture(&Img_Block_Tail[1], "Images/Block_Tail_Right.png");
    Load_Texture(&Img_Block_Ripple[2], "Images/Block_Ripple_Down.png");
    Load_Texture(&Img_Block_Tail[2], "Images/Block_Tail_Down.png");
    Load_Texture(&Img_Block_Ripple[3], "Images/Block_Ripple_Left.png");
    Load_Texture(&Img_Block_Tail[3], "Images/Block_Tail_Left.png");
    for (i = 1; i < DONE_RIPPLE; i++)
        Offset_Ripple[i] = Offset_Ripple[i - 1] * 0.96f;
    for (i = 1; i < DONE_RIPPLE; i++)
        Offset_Ripple[i] = (int)Offset_Ripple[i];
    for (i = 1; i < DONE_TAIL; i++)
        for (j = 0; j < 3; j++)
            Offset_Tail[j][i] = Offset_Tail[j][i - 1] * 0.96f;
    for (i = 1; i < DONE_TAIL; i++)
        for (j = 0; j < 3; j++)
            Offset_Tail[j][i] = (int)Offset_Tail[j][i];
    Init_Pos_LRBT();
    Init_Pos_Offset();
    Init_Pos_Ani[0] = &Init_Pos_Ani_Up;
    Init_Pos_Ani[1] = &Init_Pos_Ani_Right;
    Init_Pos_Ani[2] = &Init_Pos_Ani_Down;
    Init_Pos_Ani[3] = &Init_Pos_Ani_Left;
    Action_Effect_Ani[0] = &Action_Effect_Ani_Up;
    Action_Effect_Ani[1] = &Action_Effect_Ani_Right;
    Action_Effect_Ani[2] = &Action_Effect_Ani_Down;
    Action_Effect_Ani[3] = &Action_Effect_Ani_Left;
    Check_Equal[0] = &Check_Equal_Up;
    Check_Equal[1] = &Check_Equal_Right;
    Check_Equal[2] = &Check_Equal_Down;
    Check_Equal[3] = &Check_Equal_Left;
    Create_Joint_Square[0] = &Create_Joint_Square_Up;
    Create_Joint_Square[1] = &Create_Joint_Square_Right;
    Create_Joint_Square[2] = &Create_Joint_Square_Down;
    Create_Joint_Square[3] = &Create_Joint_Square_Left;
    for (i = 0; i < MAX; i++) {
        for (j = 0; j < MAX; j++) {
            BFS_Mark[i][j] = 0;
        }
    }
}

void Init_GL()
{
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, WIDTH, HEIGHT, 0);
    glViewport(0, 0, WIDTH, HEIGHT);
    glMatrixMode(GL_MODELVIEW);
    glClearColor(0.2f, 0.6f, 0.6f, 1.0f);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    Init_Game();
}

void Display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    if (!Check_Done_Effect()) {
        for (i = 0; i < Count_Animation; i++) {
            glColor3fv(Color_Block[Animation[i].Color]);
            Draw_Effect_Ani(&Animation[i]);
        }
    }
    if (Count_Joint_Square > 0) {
        glDisable(GL_TEXTURE_2D);
        for (i = 0; i < Count_Joint_Square; i++) {
            glBegin(GL_POLYGON);
            glVertex2f(Joint_Square[i].Left, Joint_Square[i].Bottom);
            glVertex2f(Joint_Square[i].Right, Joint_Square[i].Bottom);
            glVertex2f(Joint_Square[i].Right, Joint_Square[i].Top);
            glVertex2f(Joint_Square[i].Left, Joint_Square[i].Top);
            glEnd();
        }
        glEnable(GL_TEXTURE_2D);
    }
    Map_Texture(&Img_Block_Full);
    for (i = 0; i < MAX; i++) {
        for (j = 0; j < MAX; j++) {
            if (Map[i][j] != -1) {
                glColor3fv(Color_Block[Map[i][j]]);
                glBegin(GL_POLYGON);
                glTexCoord2f(0.0f, 0.0f);
                glVertex2f(Pos_Left[j], Pos_Bottom[i]);
                glTexCoord2f(1.0f, 0.0f);
                glVertex2f(Pos_Right[j], Pos_Bottom[i]);
                glTexCoord2f(1.0f, 1.0f);
                glVertex2f(Pos_Right[j], Pos_Top[i]);
                glTexCoord2f(0.0f, 1.0f);
                glVertex2f(Pos_Left[j], Pos_Top[i]);
                glEnd();
            }
        }
    }
    glutSwapBuffers();
}

void Resize(int x, int y)
{
    glutPositionWindow(POS_X, POS_Y);
    glutReshapeWindow(WIDTH, HEIGHT);
}

void Timer(int value)
{
    if (!Check_Done_Effect()) {
        Pos_Effect++;
        for (i = 0; i < Count_Animation; i++) {
            Action_Effect_Ani[Animation[i].Drt](&Animation[i]);
        }
        if (Check_Done_Effect()) {
            BFS_Degree--;
            Count_Joint_Square -= BFS_Count_List[BFS_Degree];
            if (BFS_Degree > -1) {
                Pos_Effect = 0;
                Count_Animation = 0;
                for (i = 0; i < BFS_Count_List[BFS_Degree]; i++)
                    Create_Animation(BFS_List[BFS_Degree][i].x, BFS_List[BFS_Degree][i].y, BFS_List[BFS_Degree][i].Drt);
                glutTimerFunc(INTERVAL, Timer, 0);
            }
        } else
            glutTimerFunc(INTERVAL, Timer, 0);
    }
    glutPostRedisplay();
}

void Keyboard(GLubyte key, int x, int y)
{
    if (Check_Done_Effect()) {
        BFS_Find(2, 2);
        BFS_Degree--;
        if (BFS_Degree > -1) {
            Pos_Effect = 0;
            Count_Animation = 0;
            for (i = 0; i < BFS_Count_List[BFS_Degree]; i++)
                Create_Animation(BFS_List[BFS_Degree][i].x, BFS_List[BFS_Degree][i].y, BFS_List[BFS_Degree][i].Drt);
        }
        glutTimerFunc(0, Timer, 0);
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowPosition(POS_X, POS_Y);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("Merge Shop");
    Init_GL();
    glutKeyboardFunc(Keyboard);
    glutDisplayFunc(Display);
    glutReshapeFunc(Resize);
    glutMainLoop();
    return 0;
}

#include "../Library/loadpng.h"

#define MAX_NUM 10

typedef unsigned char ubyte;
typedef unsigned uint;

typedef struct Image {
    ubyte* img;
    uint w, h;
} Image;

Image Img;

float Color_Float[MAX_NUM][3] = {
    { 0.902f, 0.675f, 0.706f },
    { 0.655f, 0.847f, 0.925f },
    { 0.757f, 0.878f, 0.675f },
    { 0.918f, 0.906f, 0.580f },
    { 0.890f, 0.725f, 0.914f },
    { 0.953f, 0.443f, 0.392f },
    { 0.553f, 0.592f, 0.847f },
    { 0.502f, 0.890f, 0.839f },
    { 0.925f, 0.682f, 0.733f },
	{ 0.929f, 0.922f, 0.592f }
};

int Color_Int[MAX_NUM][3];

int main(int argc, char** argv)
{
    lodepng_decode32_file(&Img.img, &Img.w, &Img.h, "Images180/01.png");
    int i, j, k;
    char str[20];
    for (i = MAX_NUM-1; i < MAX_NUM; i++)
        for (j = 0; j < 3; j++)
            Color_Int[i][j] = Color_Float[i][j] * 255;
    ubyte* ptr;
    for (k = MAX_NUM-1; k < MAX_NUM; k++) {
        ptr = Img.img;
        for (i = 0; i < Img.h; i++) {
            for (j = 0; j < Img.w; j++) {
                *ptr = Color_Int[k][0];
                ptr++;
                *ptr = Color_Int[k][1];
                ptr++;
                *ptr = Color_Int[k][2];
                ptr++;
                ptr++;
            }
        }
        sprintf(str, "Images180/%d.png", k);
        lodepng_encode32_file(str, Img.img, Img.w, Img.h);
    }
    free(Img.img);
    return 0;
}
